package mooc.vandy.java4android.calculator.logic;

import mooc.vandy.java4android.calculator.logic.Add;
import mooc.vandy.java4android.calculator.logic.Divide;
import mooc.vandy.java4android.calculator.logic.Multiply;
import mooc.vandy.java4android.calculator.logic.Subtract;
import mooc.vandy.java4android.calculator.ui.ActivityInterface;

/**
 * Performs an operation selected by the user.
 */
public class Logic 
       implements LogicInterface {
    /**
     * Reference to the Activity output.
     */
    protected ActivityInterface mOut;

    /**
     * Constructor initializes the field.
     */
    public Logic(ActivityInterface out){
        mOut = out;
    }

    /**
     * Constants to map the operation name to an integer
     *
     */
    public static int ADDITION = 1; // =addition,
    public static int SUBSTRACTION = 2; // 2=subtraction,
    public static int MULTIPLICATION = 3; // 3=multiplication, and
    public static int DIVISION = 4; // 4=division. N

    /**
     * Perform the @a operation on @a argumentOne and @a argumentTwo.
     * We use polymorphism here to take advantage of the fact that all
     *    mathematical operations follow the same format. We use a switch
     *    statment to get the correct math object, then call that object's
     *    process method.
     *
     */
    public void process(int argumentOne,
                        int argumentTwo,
                        int operation){

        MathematicalOperation mathObject;

        switch (operation) {
            case 1:
                mathObject = new Add();
                break;
            case 2:
                mathObject = new Subtract();
                break;
            case 3:
                mathObject = new Multiply();
                break;
            case 4:
            default:
                mathObject = new Divide();
                break;
        }

        mOut.print(mathObject.process(argumentOne, argumentTwo));
    }
}
