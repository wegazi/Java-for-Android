package mooc.vandy.java4android.gate.logic;

/**
 * @@ Julie, please fill in here.
 */
public class Gate {
  
    // TODO -- Fill in your code here
  
}
