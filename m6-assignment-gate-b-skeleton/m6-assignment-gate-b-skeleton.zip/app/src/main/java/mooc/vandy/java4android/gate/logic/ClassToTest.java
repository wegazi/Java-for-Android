package mooc.vandy.java4android.gate.logic;

/**
 * Enum to indicate which class to test.
 */
public enum ClassToTest {
    Corral, Herd
}
